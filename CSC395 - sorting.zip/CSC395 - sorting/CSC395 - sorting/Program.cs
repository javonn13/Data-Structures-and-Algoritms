﻿using System;

namespace CSC395___sorting
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = {3, 7, 4, 5, 2, 1 };
            //BubbleSort2(numbers);
            //SelectionSort(numbers);
            QuickSort(numbers);
            PrintArray(numbers);
        }

        static void QuickSort(int[] arr) //for users
        {
            QuickSortHelper(arr, 0, arr.Length - 1);
        }

        //better for developers
        static void QuickSortHelper(int[] arr, int startIndex, int endIndex)
        {
            if(startIndex<endIndex)
            {
                //partition around a pivot
                int q = Partition(arr, startIndex, endIndex);
                QuickSortHelper(arr, startIndex, q - 1);
                QuickSortHelper(arr, q + 1, endIndex);
            }
        }


        static int Partition(int[] arr, int startIndex, int endIndex)
        {
            int i = startIndex - 1; //keeps track of values less than pivot
            int pivot = arr[endIndex]; //pivot is the last element

            for (int j=startIndex; j<endIndex;j++) //loop through values
            {
                if(arr[j] < pivot)
                {
                    i++;
                    //swap elements at position i and j
                    int tmp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = tmp;
                }
            }
            i++;
            int tmp2 = arr[i];
            arr[i] = arr[endIndex];
            arr[endIndex] = tmp2;

            return i;
        }

        static void SelectionSort(int[] arr)
        {
            //traverse the array
            for(int pos = 0; pos<arr.Length-1; pos++)
            {
                int posForMin = pos;
                for(int i = pos+1; i< arr.Length; i++)
                {
                    if (arr[i] < arr[posForMin])//if I find a smaller value
                        posForMin = i;
                }
                //at the end of this loop, posForMin is the position for smallest
                //swap values at position: posForMin and pos
                int tmp = arr[pos];
                arr[pos] = arr[posForMin];
                arr[posForMin] = tmp;
            }
        }

        //O(n^2)
        static void BubbleSort(int[] arr)
        {
            for(int i=0; i<arr.Length-1; i++)
            {
                for (int pos = 0; pos < arr.Length - 1; pos++)
                {
                    //if two adjacent elements are not "sorted"
                    //if the subsequent number is greater than curr
                    if (arr[pos] > arr[pos + 1]) //the swap
                    {
                        int tmp = arr[pos];
                        arr[pos] = arr[pos + 1];
                        arr[pos + 1] = tmp;
                    }
                }
            }
           
        }

        //O(n^2) best and worst
        static void BubbleSort2(int[] arr)
        {
            for (int i = 0; i < arr.Length - 1; i++)
            {
                for (int pos = 0; pos < arr.Length - 1 -i; pos++)
                {
                    //if two adjacent elements are not "sorted"
                    //if the subsequent number is greater than curr
                    if (arr[pos] > arr[pos + 1]) //the swap
                    {
                        int tmp = arr[pos];
                        arr[pos] = arr[pos + 1];
                        arr[pos + 1] = tmp;
                    }
                }
            }
        }

        static void PrintArray(int[] arr)
        {
            foreach(int number in arr)
            {
                Console.Write(number + " ");
            }
            Console.WriteLine();
        }
    }
}
